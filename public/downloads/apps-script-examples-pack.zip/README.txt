Apps Script examples placeholder for MVP Template Center.
Use fictional data only.
