Lecture practice files placeholder for MVP Template Center.
Use fictional data only.
