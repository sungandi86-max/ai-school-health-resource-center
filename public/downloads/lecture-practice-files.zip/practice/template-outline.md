# Practice Template

- Prepare fictional sample data.
- Review before sharing.
